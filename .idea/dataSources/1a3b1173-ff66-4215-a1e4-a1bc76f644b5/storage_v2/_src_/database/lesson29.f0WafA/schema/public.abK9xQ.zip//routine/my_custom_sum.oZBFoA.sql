create function my_custom_sum(a integer, b integer, c integer) returns integer
    language sql
BEGIN ATOMIC
 RETURN ((a + b) + c);
END;

alter function my_custom_sum(integer, integer, integer) owner to postgres;

