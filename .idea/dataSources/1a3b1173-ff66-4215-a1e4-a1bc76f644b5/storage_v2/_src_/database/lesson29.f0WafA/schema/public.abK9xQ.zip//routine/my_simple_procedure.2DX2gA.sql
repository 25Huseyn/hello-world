create procedure my_simple_procedure()
    language sql
BEGIN ATOMIC
 INSERT INTO users (name, email, phone_number)
   VALUES ('Rembo'::character varying, 'Rembo.Mamedov@gmail.com'::character varying, 435435435);
END;

alter procedure my_simple_procedure() owner to postgres;

